/*
    HeapTestEngine.h

    Header file for heap test engine
    Used for CSCI 352 Assignment 1, Spring 2015

    David Bover, April 2015
*/

void heap_test();

