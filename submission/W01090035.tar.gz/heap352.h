/*  heap352.h

    Header file for heap management library routines
    CSCI 352, Assignment 1
    Spring, 2015

    David Bover, April, 2015

*/

void *malloc352 (int size);


void free352 (void *ptr);
